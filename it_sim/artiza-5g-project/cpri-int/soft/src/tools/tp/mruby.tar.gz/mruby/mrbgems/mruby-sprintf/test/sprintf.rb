##
# Kernel#sprintf Kernel#format Test

